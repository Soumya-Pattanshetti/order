export const environment = {
  production: true,
  baseAPIURL: ""
};
