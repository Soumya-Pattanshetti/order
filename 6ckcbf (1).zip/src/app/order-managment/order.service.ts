import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs";
//import { environment } from "src/environments/environment";

const httpOptions = {
  headers: new HttpHeaders({ "Content-Type": "application/json" })
};
//const api = environment.baseAPIURL;
const api = "localhost:8083";
@Injectable({
  providedIn: "root"
})
export class OrderService {
  requestHeader = new HttpHeaders({});
  constructor(private httpClient: HttpClient) {}

  getAllOrders(): Observable<any> {
    return this.httpClient.get<any>(api + "/order", httpOptions);
  }

  createOrder(order: any): Observable<any> {
    return this.httpClient.post<any>(api + "/order", order, httpOptions);
  }

  updateOrder(order: any): Observable<any> {
    return this.httpClient.put<any>(api + "/order", order, httpOptions);
  }

  deleteOrder(orderId: any): Observable<any> {
    return this.httpClient.delete<any>(api + "/order", orderId);
  }
}
