import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup } from "@angular/forms";
import { OrderService } from "./order.service";
@Component({
  selector: "app-order",
  templateUrl: "./order.component.html",
  styleUrls: ["./order.component.css"]
})
export class OrderComponent implements OnInit {
  orderForm: FormGroup;
  allOrderData: any[] = [];
  orderId: any;
  isUpdate: boolean;

  constructor(private fb: FormBuilder, private os: OrderService) {}

  ngOnInit() {
    this.orderForm = this.fb.group({
      carName: "",
      model: "",
      date: "",
      fcode: "petrol",
      sysCode: 1,
      dealerId: undefined,
      indicator: "",
      orderId: undefined
    });
    this.dummyData();
    // this.getAllOrder();
  }

  createOrder() {
    const formValue = this.orderForm.value;
    this.os.createOrder(formValue).subscribe(
      (res) => {
        alert("Order Placed");
        // this.getAllOrder();
      },
      (error) => {
        alert("something went wrong, please try again later");
      }
    );
  }

  getAllOrder() {
    this.os.getAllOrders().subscribe((res) => {
      this.allOrderData = res;
    });
  }

  deleteOrder(orderId) {
    let result = confirm("Want to delete?");
    if (result) {
      this.os.deleteOrder(orderId).subscribe(
        (res) => {
          alert("order deleted");
          // this.getAllOrder();
        },
        (error) => {
          alert("something went wrong, please try again later");
        }
      );
    }
  }

  editOrder(order) {
    this.orderId = order.orderId;
    this.isUpdate = true;
    this.orderForm.setValue(order);
  }

  reset() {
    this.isUpdate = false;
    this.orderForm.reset();
  }

  dummyData() {
    this.allOrderData = [
      {
        carName: "Innova",
        model: "MUV",
        date: "",
        fcode: "petrol",
        sysCode: 1,
        dealerId: 1,
        indicator: "Left",
        orderId: 1
      },
      {
        carName: "Alto",
        model: "Hatch",
        date: "",
        fcode: "disel",
        sysCode: 2,
        dealerId: 1,
        indicator: "Right",
        orderId: 2
      }
    ];
  }
}
